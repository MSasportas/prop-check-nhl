# Historical backtest plan (DS, written 2026-10-19 before any historical price beyond the 1-game probe)

Follows TEAM.md section 7 item 19 (pre-registered 9:40 AM ET). Nothing below changes a hypothesis; it only fixes the mechanics.

## Data
- NHL: 2025-26 schedule (api-web schedule weeks: game id, teams, startTimeUTC), boxscores for every regular-season game
  (grading exactly as scripts/grade.py read_box/result_for; shots_trusted check logged), stats store = 2024-25 skater rows
  (DS cache, NHL stats REST skater/summary per game) + repo seed stats_seed_20252026 (2025-26 skaters, 2024-25+2025-26 teams).
  Goalie rows (stats REST goalie/summary isGame) for the saves exploratory model only.
- Odds API historical (key read from scratch file at runtime, never logged):
  (a) events list once per game day at 12:00 ET (1 credit) -> event ids, matched to NHL games by teams + start within 6 h
      (odds.match_events logic);
  (b) shots (player_shots_on_goal, hardrockbet, us2) at commence - 45 min for every matched game (10 credits);
  (c) saves at -45 min for ~250 games spread over months (stratified random, seed 19);
  (d) shots at 13:00 ET same day for ~150 games (stratified random, seed 23) for open->close / CLV.
  Snapshot accepted only if its timestamp is before puck and within 3 h of the target. Every response cached on disk;
  ledger.jsonl records credits from x-requests-remaining / x-requests-last. Hard stop at 18,000 used.
- Names: repo names.Matcher on each game's two rosters (players whose latest prior row is with that team, plus players
  in that game's boxscore for that team; the latter only affects matching of players who then played, i.e. trades/call-ups,
  never an outcome). Unmatched rate reported.

## Model path (no leakage)
- Production code imported from the repo read-only (engine.Inputs, engine.candidates, engine.best_per_player, odds.build_view,
  odds.check_pair, model.*). Store rows with date < slate only (Inputs already filters). Lineups = {} (all 'early'),
  missed-last-game -> not eligible (engine does this when lineup is not 'in'). Feed checks (hold 3-11%, stale 60 min vs
  snapshot time) applied as in production. Verify by hand on a few lines.
- Params in model.py are stated as fit on 2024-25. Check and report anything fit on 2025-26.

## Hypotheses (frozen, TEAM.md 19)
- H1 v2.0 config as is (edge 0..0.05, lines 1.5/2.5, over_hold, 0.7 blend). Uncapped (every qualifying side, best-edge line
  per player per night not applied) and capped (engine best_per_player + 2/game + 8/night by edge, one pass per night
  at the -45 snapshot; note: live caps act through the day, here one read).
- H2 rule A: v2.0 with edge_cap null, lines 1.5/2.5/3.5, no caps.
- H3 v1.0 (common.rules_for for a slate <= 2026-10-18).
- H4 blind unders 1.5 + 2.5, price -200..+120, ok pairs, matched players.
- H5 log loss / Brier: model (engine p_over) vs over-hold de-vig vs proportional de-vig, by month, on every ok two-way
  line where the model runs and the player is eligible.
- Scoring: 1u flat at snapshot price, reg+OT, void no TOI, push on whole-number tie. Per hypothesis: n, hit, avg BE, units,
  ROI, game-clustered bootstrap 90/95% (2,000 draws), ROI by month, line, side, price band.
- Primary success (H1): ROI >= +3%, 90% lower bound > 0, positive in >= 4 of 6 months. Fail: ROI <= 0.

## After H1-H5 are written: exploratory, walk-forward only
- Months: Oct+Nov ... Train on months <= m, test m+1, for m+1 in Nov..Feb. Lockbox = games on/after 2026-03-01: untouched
  until ONE rule is frozen (logged in results.md with timestamp), then scored once.
- Every variant counted; expected false positives reported.
- Placebo: shuffle model p_over within (night, line) and rerun H1, 500 shuffles.
