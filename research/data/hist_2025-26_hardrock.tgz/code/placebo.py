"""Replica check (lib.v2_sides == engine H1 uncapped) and the shuffle placebo for H1."""
import json, os, random, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib import *
L = load_lines("shots45")
P = json.load(open(os.path.join(WORK, "shots45_picks.json")))
eng = {(p["gid"], p["pid"], p["line"], p["side"], p["price"]) for p in P["H1_uncapped"]}
rep = set()
for r in L:
    for s in v2_sides(r):
        rep.add((r["gid"], r["pid"], r["line"], s[0], s[1]))
print("engine", len(eng), "replica", len(rep), "both", len(eng & rep), "only engine", list(eng - rep)[:3], "only replica", list(rep - eng)[:3])
def run(po):
    bs = []
    for r, p in zip(L, po):
        for s in v2_sides(r, p_over=p):
            b = grade_bet(r, s[0], s[1])
            if b: bs.append(b)
    return bs
real = summ(run([r.get("p_over") for r in L]), ci=False)
print("real", fmt(real, False))
groups = {}
for i, r in enumerate(L):
    if eligible(r) and r["line"] in (1.5, 2.5):
        groups.setdefault((r["date"], r["line"]), []).append(i)
rnd = random.Random(42)
rois, ns = [], []
for t in range(500):
    po = [r.get("p_over") for r in L]
    for idx in groups.values():
        vals = [po[i] for i in idx]
        rnd.shuffle(vals)
        for i, v in zip(idx, vals):
            po[i] = v
    s = summ(run(po), ci=False)
    rois.append(s["roi"]); ns.append(s["n"])
rois.sort()
pv = sum(1 for x in rois if x >= real["roi"]) / len(rois)
out = "Placebo (model shuffled within night x line, 500 runs): mean ROI %+.2f%%, 5-95%% [%+.2f, %+.2f], mean n %d; real %+.2f%% (n %d); share of shuffles >= real: %.3f" % (
    100 * sum(rois) / len(rois), 100 * rois[25], 100 * rois[475], sum(ns) / len(ns), 100 * real["roi"], real["n"], pv)
print(out)
open(os.path.join(WORK, "placebo.txt"), "w").write(out + "\n")
