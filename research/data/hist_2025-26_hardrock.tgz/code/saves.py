"""Saves sample: production team-level goalie_prob (as shadow.py) and a goalie-specific variant, walk-forward only."""
import glob
import json
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import build  # noqa: E402  (sets PC_DATA_DIR, imports the repo)
from lib import *  # noqa

engine, model = build.engine, build.model
st, nm = build.load_store()
L = [json.loads(l) for l in open(os.path.join(WORK, "saves45_lines.jsonl"))]
G = {g["id"]: g for g in build.GAMES}
gl = {}
for f in sorted(glob.glob(os.path.join(build.RAW, "nhl", "rest", "goalie_summary_*.json"))):
    for r in json.load(open(f)):
        gl.setdefault(r["playerId"], []).append((r["gameDate"][:10], r["shotsAgainst"] or 0, r["saves"] or 0, r["gamesStarted"] or 0))
for k in gl:
    gl[k].sort()
inps = {}
for r in L:
    g = G[r["gid"]]
    if r["date"] not in inps:
        inps[r["date"]] = engine.Inputs(build.common.load_config(), None, r["date"], build.SEASON, [], st, {}, {}, {}, {}, [])
    inp = inps[r["date"]]
    lg = inp.league()[0]
    tsa = model.team_factor([x for x in st.teams.get(r["team"], []) if x["date"] < r["date"]], "sa", lg, model.GK["K"])
    osf = model.team_factor([x for x in st.teams.get(r["opp"], []) if x["date"] < r["date"]], "sf", lg, model.GK["K"])
    gp = model.goalie_prob(r["line"], {"home": r["home"], "league_sf": lg, "team_sa_f": tsa, "opp_sf_f": osf})
    r["p_over"], r["mu"] = gp["p"], gp["mu"]
    # goalie-specific: expected shots against x this goalie's shrunk prior save% (prior starts only)
    prior = [x for x in gl.get(r["pid"], []) if x[0] < r["date"]]
    sa = sum(x[1] for x in prior[-60:]); sv = sum(x[2] for x in prior[-60:])
    lsv = 0.900
    svp = (1500 * lsv + sv) / (1500 + sa)
    esa = lg * tsa * osf * (1.0 if r["home"] else 1.0)
    mu2 = esa * svp
    r["p2_over"] = model.nb_sf(math.floor(r["line"]) + 1, mu2, model.GK["r"])
    r["n_starts"] = sum(x[3] for x in prior)
pop = [r for r in L if r["ok"] and r["result"] == "OK"]
out = ["# Saves sample (Hard Rock, -45 min, %d games, %d graded two-way lines)\n" % (len({r['gid'] for r in pop}), len(pop))]
y = lambda r: 1 if r["actual"] > r["line"] else 0
for nm_, f in (("production goalie_prob", lambda r: r["p_over"]), ("goalie-specific (sv%)", lambda r: r["p2_over"]),
               ("book over-hold", lambda r: fair_over(r, 1.0)), ("book proportional", lambda r: fair_over(r, None))):
    out.append("LL %-24s %.4f  Brier %.4f" % (nm_, sum(ll(f(r), y(r)) for r in pop) / len(pop),
                                             sum((f(r) - y(r)) ** 2 for r in pop) / len(pop)))
n = len(pop)
hold = sum(be(r["over"]) + be(r["under"]) - 1 for r in pop) / n
obe = sum(be(r["over"]) for r in pop) / n
hit = sum(y(r) for r in pop) / n
out.append("\nhold %.1f%%, over BE %.1f%%, over hit %.1f%%, k (share of hold on over) %.2f" % (100 * hold, 100 * obe, 100 * hit, (obe - hit) / hold))
bo = [grade_bet(r, "over", r["over"]) for r in pop if in_gate(r["over"])]
bu = [grade_bet(r, "under", r["under"]) for r in pop if in_gate(r["under"])]
out.append("blind overs " + fmt(summ([b for b in bo if b])))
out.append("blind unders " + fmt(summ([b for b in bu if b])))


def rule(rows, key, w=0.7, k=1.0, lo=0.0, hi=0.05):
    bs = []
    for r in rows:
        if not r["ok"] or r["result"] != "OK" or r["actual"] == r["line"]:
            continue
        po = r[key]
        fo = fair_over(r, k)
        for side in ("over", "under"):
            if not in_gate(r[side]):
                continue
            p = w * (po if side == "over" else 1 - po) + (1 - w) * (fo if side == "over" else 1 - fo)
            e = p - be(r[side])
            if lo <= e and (hi is None or e < hi):
                b = grade_bet(r, side, r[side])
                if b:
                    bs.append(b)
    return bs


dev = [r for r in pop if r["date"] < "2026-03-01"]
out.append("\nv2-style rule on saves, pre-March only (Oct-Feb, no fit; lockbox untouched):")
out.append("  production model: " + fmt(summ(rule(dev, "p_over"))))
out.append("  goalie-specific : " + fmt(summ(rule(dev, "p2_over"))))
# walk-forward: fit w in 0..1 and window by train ROI (min 30 bets), test next month
MONTHS = ["2025-10", "2025-11", "2025-12", "2026-01", "2026-02"]
for key in ("p_over", "p2_over"):
    oos = []
    ch = []
    for i, m in enumerate(MONTHS[1:]):
        tr = [r for r in dev if r["date"][:7] in MONTHS[:i + 1]]
        te = [r for r in dev if r["date"][:7] == m]
        best = None
        for w in (0.3, 0.5, 0.7, 1.0):
            for lo, hi in ((0, 0.05), (0, None), (0.02, None), (0.05, None)):
                bs = rule(tr, key, w, 1.0, lo, hi)
                if len(bs) >= 30:
                    x = sum(b["profit"] for b in bs) / len(bs)
                    if best is None or x > best[0]:
                        best = (x, w, lo, hi)
        if best:
            bs = rule(te, key, best[1], 1.0, best[2], best[3])
            oos += bs
            ch.append((m, best[1:], len(bs)))
    out.append("  walk-forward %s (16 variants): %s  picks %s" % (key, fmt(summ(oos)), ch))
open(os.path.join(WORK, "saves.md"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
