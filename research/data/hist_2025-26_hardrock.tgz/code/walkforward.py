"""Exploratory ideas, WALK-FORWARD only, on games before 2026-03-01 (lockbox untouched here).
Train on months <= m (expanding), test on m+1, for test months Nov, Dec, Jan, Feb.
Every family picks its parameters on TRAIN only (ROI with n >= MIN_N, or log loss where stated)."""
import json
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib import *  # noqa

LOCK = "2026-03-01"
ALL = [json.loads(l) for l in open(os.path.join(WORK, "shots45_feat.jsonl"))]
DEV = [r for r in ALL if r["date"] < LOCK]
MONTHS = ["2025-10", "2025-11", "2025-12", "2026-01", "2026-02"]
TESTS = MONTHS[1:]
MIN_N = 150
VARIANTS = {}


def bets_for(rows, prm, p_fn=None):
    bs = []
    flt = prm.get("filter")
    for r in rows:
        if flt and not flt(r):
            continue
        po = p_fn(r) if (p_fn and eligible(r)) else None
        for s in v2_sides(r, w=prm.get("w", 0.7), k=prm.get("k", 1.0), lo=prm.get("lo", 0.0), hi=prm.get("hi", 0.05),
                          lines=prm.get("lines", (1.5, 2.5)), p_over=po):
            if prm.get("side") and s[0] != prm["side"]:
                continue
            if prm.get("band") and not prm["band"](s[1]):
                continue
            b = grade_bet(r, s[0], s[1])
            if b:
                b["edge"] = s[2]
                bs.append(b)
    return bs


def roi(bs):
    return sum(b["profit"] for b in bs) / len(bs) if bs else -9


def pick_by_roi(train, grid, p_fn=None):
    best = None
    for prm in grid:
        bs = bets_for(train, prm, p_fn)
        if len(bs) < MIN_N:
            continue
        x = roi(bs)
        if best is None or x > best[0]:
            best = (x, prm)
    return best[1] if best else None


def logit(p):
    p = min(max(p, 1e-6), 1 - 1e-6)
    return math.log(p / (1 - p))


def y(r):
    return 1 if r["actual"] > r["line"] else 0


def ll_rows(train):
    return [r for r in train if eligible(r) and r["result"] == "OK" and r["actual"] != r["line"]]


# ---------------------------------------------------------------- families
WINDOWS = [dict(lo=lo, hi=hi) for lo in (0.0, 0.01, 0.02, 0.03) for hi in (0.03, 0.05, 0.08, None) if hi is None or hi > lo]


def fam_baseline(train):
    return dict(), None


def fam_blend(train):
    """w, k by train log loss on the blended over chance; then the edge window by train ROI."""
    rows = ll_rows(train)
    best = None
    for w in [i / 10 for i in range(11)]:
        for k in (None, 0.0, 0.25, 0.5, 0.75, 1.0):
            s = sum(ll(w * r["p_over"] + (1 - w) * fair_over(r, k), y(r)) for r in rows) / len(rows)
            if best is None or s < best[0]:
                best = (s, w, k)
    _, w, k = best
    grid = [dict(w=w, k=k, **win) for win in WINDOWS]
    return pick_by_roi(train, grid) or dict(w=w, k=k), None


def fit_logreg(X, Y, iters=25):
    d = len(X[0])
    b = [0.0] * d
    for _ in range(iters):
        g = [0.0] * d
        Hm = [[0.0] * d for _ in range(d)]
        for x, t in zip(X, Y):
            z = sum(bi * xi for bi, xi in zip(b, x))
            p = 1 / (1 + math.exp(-max(-30, min(30, z))))
            for i in range(d):
                g[i] += (t - p) * x[i]
                for j in range(d):
                    Hm[i][j] += p * (1 - p) * x[i] * x[j]
        for i in range(d):
            Hm[i][i] += 1e-6
        # solve Hm * step = g (Gauss)
        A = [Hm[i][:] + [g[i]] for i in range(d)]
        for c in range(d):
            piv = max(range(c, d), key=lambda r_: abs(A[r_][c]))
            A[c], A[piv] = A[piv], A[c]
            for r_ in range(d):
                if r_ != c:
                    f = A[r_][c] / A[c][c]
                    for k in range(c, d + 1):
                        A[r_][k] -= f * A[c][k]
        step = [A[i][d] / A[i][i] for i in range(d)]
        b = [bi + si for bi, si in zip(b, step)]
    return b


def fam_stack(train):
    """over chance = logistic(a + b1 logit(model) + b2 logit(book proportional)), fit on train; window by train ROI."""
    rows = ll_rows(train)
    X = [[1.0, logit(r["p_over"]), logit(fair_over(r, None))] for r in rows]
    b = fit_logreg(X, [y(r) for r in rows])
    fn = lambda r: 1 / (1 + math.exp(-(b[0] + b[1] * logit(r["p_over"]) + b[2] * logit(fair_over(r, None)))))
    grid = [dict(w=1.0, **win) for win in WINDOWS]
    prm = pick_by_roi(train, grid, fn) or dict(w=1.0)
    prm["coef"] = [round(x, 3) for x in b]
    return prm, fn


def grid_family(grid):
    def f(train):
        return pick_by_roi(train, grid) or dict(), None
    f.grid = grid
    return f


LINESETS = [(1.5,), (2.5,), (3.5,), (1.5, 2.5), (1.5, 2.5, 3.5), (2.5, 3.5)]
F_lines = grid_family([dict(lines=ls) for ls in LINESETS])
F_side = grid_family([dict(side=None), dict(side="under"), dict(side="over")])
F_home = grid_family([dict(), dict(filter=lambda r: r["home"]), dict(filter=lambda r: not r["home"])])
F_rest = grid_family([dict(), dict(filter=lambda r: r["team_rest"] != 0), dict(filter=lambda r: r["team_rest"] == 0),
                      dict(filter=lambda r: r["opp_rest"] != 0), dict(filter=lambda r: r["opp_rest"] == 0),
                      dict(filter=lambda r: (r["team_rest"] or 0) >= 2), dict(filter=lambda r: (r["opp_rest"] or 0) >= 2)])
F_opp = grid_family([dict()] + [dict(filter=(lambda lo, hi: lambda r: r["opp_f"] is not None and lo <= r["opp_f"] < hi)(lo, hi))
                                for lo, hi in ((0, 0.97), (0.97, 1.03), (1.03, 9), (0, 1.03), (0.97, 9))])
F_pp = grid_family([dict(), dict(filter=lambda r: r.get("pp_min") is not None and r["pp_min"] >= 1.5),
                    dict(filter=lambda r: r.get("pp_min") is not None and r["pp_min"] < 1.5),
                    dict(filter=lambda r: r.get("pp_min") is not None and r["pp_min"] < 0.5)])
F_toi = grid_family([dict(), dict(filter=lambda r: r.get("toi_trend") is not None and r["toi_trend"] > 1),
                     dict(filter=lambda r: r.get("toi_trend") is not None and r["toi_trend"] < -1),
                     dict(filter=lambda r: r.get("toi_trend") is not None and abs(r["toi_trend"]) <= 1)])
BANDS = {"a": lambda p: p <= -150, "b": lambda p: -149 <= p <= -121, "c": lambda p: -120 <= p <= 100 and (p < 0 or p == 100),
         "d": lambda p: 101 <= p}
F_price = grid_family([dict()] + [dict(band=(lambda ks: lambda p: any(BANDS[k](p) for k in ks))(ks))
                                  for ks in ("a", "b", "c", "d", "ab", "cd", "bc", "abc", "bcd")])
F_edge = grid_family([dict(**win) for win in WINDOWS])

FAMILIES = [("v2 as is (reference, no fit)", fam_baseline, 1),
            ("blend w + de-vig k (LL) + edge window", fam_blend, 66 + len(WINDOWS)),
            ("stacked logistic (model, book) + window", fam_stack, 1 + len(WINDOWS)),
            ("edge band / cap", F_edge, len(WINDOWS)),
            ("line subsets", F_lines, len(LINESETS)),
            ("side", F_side, 3),
            ("home / road", F_home, 3),
            ("rest / back-to-back", F_rest, 7),
            ("opponent shot suppression", F_opp, 6),
            ("power-play role", F_pp, 4),
            ("ice-time trend", F_toi, 4),
            ("price band", F_price, 10)]


def run_family(fn):
    oos, chosen = [], []
    for i, m in enumerate(TESTS):
        train = [r for r in DEV if r["date"][:7] in MONTHS[:i + 1]]
        test = [r for r in DEV if r["date"][:7] == m]
        prm, pfn = fn(train)
        bs = bets_for(test, prm, pfn)
        oos += bs
        chosen.append((m, {k: v for k, v in prm.items() if k not in ("filter", "band")} | (
            {"filter": "yes"} if prm.get("filter") else {}) | ({"band": "yes"} if prm.get("band") else {}), len(bs), roi(bs)))
    return oos, chosen


def describe(fn, prm):
    if hasattr(fn, "grid"):
        return "grid index %d" % next(i for i, g in enumerate(fn.grid) if g is prm)
    return str({k: v for k, v in prm.items() if k not in ("filter", "band")})


if __name__ == "__main__":
    out = ["# Walk-forward (train months <= m, test m+1; Nov-Feb; lockbox Mar 1+ untouched)\n",
           "| family | variants | OOS n | hit | BE | units | ROI | 90% CI | by test month (ROI) |", "|---|---|---|---|---|---|---|---|---|"]
    res = {}
    total_var = 0
    for name, fn, nv in FAMILIES:
        total_var += nv
        oos, chosen = run_family(fn)
        s = summ(oos)
        res[name] = (s, chosen)
        mon = " / ".join("%s %+.1f%% (n%d)" % (m[5:], 100 * x if n else 0, n) for m, c, n, x in chosen)
        out.append("| %s | %d | %d | %.1f%% | %.1f%% | %+.1f | %+.1f%% | [%+.1f, %+.1f] | %s |" % (
            name, nv, s.get("n", 0), 100 * s.get("hit", 0), 100 * s.get("be", 0), s.get("units", 0), 100 * s.get("roi", 0),
            100 * s.get("lo90", 0), 100 * s.get("hi90", 0), mon))
        print(name, fmt(s), [(m, c, n, round(x, 3)) for m, c, n, x in chosen], flush=True)
    out.append("\nTotal variants evaluated: %d across %d families (+ reference). At a 5%% one-sided bar, about %.1f families would "
               "look 'significant' by chance if none had an edge." % (total_var, len(FAMILIES) - 1, 0.05 * (len(FAMILIES) - 1)))
    open(os.path.join(WORK, "walkforward.md"), "w").write("\n".join(out) + "\n")
    print("\n".join(out))
