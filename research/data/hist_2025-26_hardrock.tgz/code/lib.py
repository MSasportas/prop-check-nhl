"""Scoring helpers for the historical backtest (stdlib)."""
import json
import math
import os
import random

H = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK = os.path.join(H, "work")


def be(a):
    return (-a) / (-a + 100.0) if a < 0 else 100.0 / (a + 100.0)


def dec(a):
    return 1.0 + (100.0 / -a if a < 0 else a / 100.0)


def in_gate(a, lo=-200, hi=120):
    return lo <= a <= hi if a < 0 else (100 <= a <= hi)


def load_lines(folder):
    rows = [json.loads(l) for l in open(os.path.join(WORK, "%s_lines.jsonl" % folder))]
    return rows


def index(rows):
    return {(r["gid"], r["pid"], r["line"]): r for r in rows}


def result(side, line, actual):
    if actual == line:
        return "PUSH"
    return "W" if (actual > line) == (side == "over") else "L"


def grade_bet(row, side, price):
    """-> dict or None (void / no result)."""
    if row is None or row["result"] != "OK":
        return None
    r = result(side, row["line"], row["actual"])
    if r == "PUSH":
        return None
    win = r == "W"
    return {"gid": row["gid"], "date": row["date"], "month": row["date"][:7], "line": row["line"], "side": side,
            "price": price, "win": win, "profit": dec(price) - 1.0 if win else -1.0, "be": be(price)}


def band(p):
    if p <= -150:
        return "a: -200..-150"
    if p <= -121:
        return "b: -149..-121"
    if p <= 100 and (p < 0 or p == 100):
        return "c: -120..+100"
    return "d: +101..+120"


def boot(bets, B=2000, seed=11):
    by = {}
    for b in bets:
        by.setdefault(b["gid"], [0.0, 0])
        by[b["gid"]][0] += b["profit"]
        by[b["gid"]][1] += 1
    g = list(by.values())
    if not g:
        return None
    rnd = random.Random(seed)
    rs = []
    n = len(g)
    for _ in range(B):
        s = c = 0
        for _ in range(n):
            x = g[rnd.randrange(n)]
            s += x[0]
            c += x[1]
        rs.append(s / c if c else 0.0)
    rs.sort()
    q = lambda f: rs[min(B - 1, max(0, int(f * B)))]
    return {"lo90": q(0.05), "hi90": q(0.95), "lo95": q(0.025), "hi95": q(0.975)}


def summ(bets, B=2000, ci=True):
    n = len(bets)
    if not n:
        return {"n": 0}
    u = sum(b["profit"] for b in bets)
    out = {"n": n, "games": len({b["gid"] for b in bets}), "hit": sum(b["win"] for b in bets) / n,
           "be": sum(b["be"] for b in bets) / n, "units": u, "roi": u / n}
    if ci:
        out.update(boot(bets, B))
    return out


def fmt(s, ci=True):
    if not s or not s.get("n"):
        return "n=0"
    t = "n=%d hit %.1f%% BE %.1f%% %+.1fu ROI %+.1f%%" % (s["n"], 100 * s["hit"], 100 * s["be"], s["units"], 100 * s["roi"])
    if ci and "lo90" in s:
        t += " 90%% [%+.1f,%+.1f] 95%% [%+.1f,%+.1f]" % (100 * s["lo90"], 100 * s["hi90"], 100 * s["lo95"], 100 * s["hi95"])
    return t


def breakdown(bets, key):
    by = {}
    for b in bets:
        by.setdefault(key(b), []).append(b)
    return {k: summ(v, ci=False) for k, v in sorted(by.items())}


def table(bets, title):
    lines = ["### " + title, "", "All: " + fmt(summ(bets)), ""]
    for nm, kf in (("month", lambda b: b["month"]), ("line", lambda b: b["line"]), ("side", lambda b: b["side"]),
                   ("price band", lambda b: band(b["price"]))):
        lines.append("| %s | n | hit | BE | units | ROI |" % nm)
        lines.append("|---|---|---|---|---|---|")
        for k, s in breakdown(bets, kf).items():
            lines.append("| %s | %d | %.1f%% | %.1f%% | %+.1f | %+.1f%% |" % (k, s["n"], 100 * s["hit"], 100 * s["be"], s["units"], 100 * s["roi"]))
        lines.append("")
    return "\n".join(lines)


def ll(p, y):
    p = min(max(p, 1e-6), 1 - 1e-6)
    return -(y * math.log(p) + (1 - y) * math.log(1 - p))


def fair_over(r, k=1.0):
    """k = share of hold on the over. k=1: over-hold (v2), None: proportional."""
    io, iu = be(r["over"]), be(r["under"])
    if k is None:
        return io / (io + iu)
    return io - k * (io + iu - 1)


def eligible(r):
    return r["ok"] and r.get("p_over") is not None and r["n"] >= 10 and not r["sitting"] and not r["missed_last"]


def v2_sides(r, w=0.7, k=1.0, lo=0.0, hi=0.05, lines=(1.5, 2.5), p_over=None, gate=(-200, 120)):
    """Replica of the engine's v2 qualify step for one line -> list of (side, price, edge, p)."""
    if not eligible(r) or (lines is not None and r["line"] not in lines):
        return []
    po_m = r["p_over"] if p_over is None else p_over
    fo = fair_over(r, k)
    out = []
    for side in ("over", "under"):
        if side == "over" and r["toi_drop"]:
            continue
        price = r[side]
        if not in_gate(price, *gate):
            continue
        ms = po_m if side == "over" else 1 - po_m
        fs = fo if side == "over" else 1 - fo
        p = w * ms + (1 - w) * fs
        e = p - be(price)
        if e >= lo - 1e-9 and (hi is None or e < hi - 1e-9):
            out.append((side, price, e, p))
    return out
