"""Historical Odds API client: cache-first, ledger, hard cap. The key is read from the secrets file at call time and
never printed, logged or written. Every log line is built from the redacted URL."""
import json
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request

H = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KEYF = os.path.join(os.path.dirname(H), "secrets", "hist_odds_key")
LEDGER = os.path.join(H, "ledger.jsonl")
CAP = 18000
BASE = "https://api.the-odds-api.com/v4/historical/sports/icehockey_nhl"


class CapReached(Exception):
    pass


def _key():
    with open(KEYF) as f:
        return f.read().strip()


def redact(s):
    return re.sub(r"apiKey=[^&\s]+", "apiKey=REDACTED", str(s))


def used_so_far():
    used = 11  # probe
    if os.path.exists(LEDGER):
        for line in open(LEDGER):
            try:
                r = json.loads(line)
            except ValueError:
                continue
            if r.get("used") is not None:
                used = max(used, int(r["used"]))
    return used


def get(path, params, cache_file, expect_cost):
    """Returns parsed JSON (from cache if present) or None. Raises CapReached before a call that could pass the cap."""
    if os.path.exists(cache_file):
        try:
            return json.load(open(cache_file))
        except ValueError:
            pass
    used = used_so_far()
    if used + expect_cost > CAP:
        raise CapReached("used %d + %d > %d" % (used, expect_cost, CAP))
    q = dict(params)
    q["apiKey"] = _key()
    url = BASE + path + "?" + urllib.parse.urlencode(q, safe=",:")
    shown = redact(url)
    for attempt in range(2):
        status, hdr, body, err = None, {}, None, None
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "pc-hist/1"}), timeout=60) as r:
                status, hdr, body = r.status, dict(r.headers), r.read()
        except urllib.error.HTTPError as e:
            status, hdr = e.code, dict(e.headers or {})
            try:
                body = e.read()
            except Exception:
                body = None
        except Exception as e:
            err = redact(repr(e))
        hl = {k.lower(): v for k, v in hdr.items()}
        rec = {"t": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "path": redact(path), "cache": os.path.basename(cache_file),
               "date": params.get("date"), "status": status, "last": hl.get("x-requests-last"),
               "remaining": hl.get("x-requests-remaining"), "used": hl.get("x-requests-used"), "err": err}
        with open(LEDGER, "a") as f:
            f.write(json.dumps(rec) + "\n")
        if status == 200 and body is not None:
            js = json.loads(body)
            with open(cache_file, "w") as f:
                json.dump(js, f)
            time.sleep(0.25)
            return js
        if status in (429, 500, 502, 503, 504) or err:
            time.sleep(3)
            continue
        if status in (401, 403):
            raise CapReached("key refused (%s)" % status)
        # 404/422 etc: no data; cache a marker so it is not paid twice
        with open(cache_file, "w") as f:
            json.dump({"_status": status, "_body": (body or b"")[:300].decode("utf-8", "replace")}, f)
        return None
    print("failed after retry:", shown, status)
    return None
