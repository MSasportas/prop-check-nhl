"""Score the frozen rule ONCE on the lockbox (games 2026-03-01 onward)."""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import walkforward as W
from lib import summ, fmt
fz = json.load(open(os.path.join(W.WORK, "frozen.json")))
assert not os.path.exists(os.path.join(W.WORK, "lockbox.txt")), "lockbox already scored"
prm = W.F_rest.grid[fz["grid_index"]]
lock = [r for r in W.ALL if r["date"] >= W.LOCK]
bs = W.bets_for(lock, prm)
s = summ(bs)
txt = "Lockbox (%s): frozen rule '%s' -> %s" % (fz["lockbox"], fz["rule"], fmt(s))
open(os.path.join(W.WORK, "lockbox.txt"), "w").write(txt + "\n")
print(txt)
