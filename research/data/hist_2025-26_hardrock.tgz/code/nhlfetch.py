import json, os, sys, time, urllib.request, urllib.parse
from datetime import date, timedelta
RAW = sys.argv[1]
UA = {"User-Agent": "Mozilla/5.0"}
def get(url, tries=3):
    for a in range(tries):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=60) as r:
                return json.loads(r.read())
        except Exception as e:
            print("err", url[:100], e, flush=True); time.sleep(2 * (a + 1))
    return None
what = sys.argv[2]
if what == "sched":
    d = date(2025, 10, 6)
    while d <= date(2026, 4, 20):
        p = os.path.join(RAW, "sched", d.isoformat() + ".json")
        if not os.path.exists(p):
            js = get("https://api-web.nhle.com/v1/schedule/%s" % d.isoformat())
            if js: json.dump(js, open(p, "w"))
            time.sleep(0.2)
        d += timedelta(days=7)
elif what == "box":
    ids = json.load(open(os.path.join(RAW, "games.json")))
    n = 0
    for g in ids:
        p = os.path.join(RAW, "box", "%s.json" % g["id"])
        if os.path.exists(p): continue
        js = get("https://api-web.nhle.com/v1/gamecenter/%s/boxscore" % g["id"])
        if js:
            # compact: what grade.read_box needs + state
            keep = {k: js.get(k) for k in ("id", "gameState", "gameScheduleState", "startTimeUTC", "gameDate", "periodDescriptor", "gameOutcome")}
            for side in ("awayTeam", "homeTeam"):
                keep[side] = {k: js[side].get(k) for k in ("abbrev", "sog", "score")}
            keep["playerByGameStats"] = js.get("playerByGameStats")
            json.dump(keep, open(p, "w"))
        n += 1
        time.sleep(0.12)
    print("box fetched", n)
elif what == "rest":
    report, season, d0, d1 = sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6]
    d, end = date.fromisoformat(d0), date.fromisoformat(d1)
    while d <= end:
        e = min(d + timedelta(days=6), end)
        p = os.path.join(RAW, "rest", "%s_%s_%s.json" % (report.replace("/", "_"), season, d.isoformat()))
        if not os.path.exists(p):
            exp = 'seasonId=%s and gameTypeId=2 and gameDate>="%s" and gameDate<="%s"' % (season, d, e)
            q = urllib.parse.urlencode({"isAggregate": "false", "isGame": "true", "limit": -1, "cayenneExp": exp})
            js = get("https://api.nhle.com/stats/rest/en/%s?%s" % (report, q))
            if js and len(js.get("data", [])) == js.get("total"):
                json.dump(js["data"], open(p, "w"))
            else:
                print("bad window", d, js and js.get("total"))
            time.sleep(0.3)
        d = e + timedelta(days=1)
print("done", what)
