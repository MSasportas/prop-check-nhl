"""Hand check: recompute the model chance for a few lines from raw rows, independent of engine.Inputs/stats.Store."""
import glob
import gzip
import json
import math
import os
import random

H = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DS2 = os.path.join(os.path.dirname(H), "ds2", "dl", "rest")
rows24 = []
for f in sorted(glob.glob(os.path.join(DS2, "skater_summary_20242025_*.json"))):
    rows24 += json.load(open(f))
seed = json.load(gzip.open("/home/claude/prop-check-nhl/data/state/stats_seed_20252026.json.gz"))
L = [json.loads(l) for l in open(os.path.join(H, "work", "shots45_lines.jsonl"))]
rnd = random.Random(3)
pick = rnd.sample([r for r in L if r.get("p_over") is not None and r["n"] >= 10], 6)


def sk_rows(pid, before):
    out = []
    for r in rows24:
        if r["playerId"] == pid and r["gameDate"][:10] < before:
            out.append((r["gameDate"][:10], r["gameId"], 20242025, round(r["timeOnIcePerGame"] or 0), r["shots"] or 0))
    for r in seed["skaters"]:
        if r[0] == pid and r[2] < before:
            out.append((r[2], r[1], 20252026, r[6], r[7]))
    return sorted(out, reverse=True)[:170]


def team_rows(team, before):
    return sorted([(t[1], t[0], t[6]) for t in seed["teams"] if t[2] == team and t[1] < before], reverse=True)


def league_sf(before):
    xs = [t[5] for t in seed["teams"] if t[1] < before]
    return sum(xs) / len(xs)


for r in pick:
    pos = seed["players"].get(str(r["pid"]), ["", "F"])[1]
    rs = sk_rows(r["pid"], r["date"])
    w = t = x = wt = tt = 0.0
    for i, (d, g, s, toi, sh) in enumerate(rs):
        disc = 1.0 if s == 20252026 else 0.7
        wi = disc * 0.5 ** (i / 40.0)
        w += wi; t += wi * toi; x += wi * sh
        wj = disc * 0.5 ** (i / 5.0)
        wt += wj; tt += wj * toi
    prior = {"F": 7.37, "D": 4.20}[pos] / 3600
    rate = (5 * 900 * prior + x) / (5 * 900 + t)
    etoi = (1 * {"F": 950.0, "D": 1150.0}[pos] + tt) / (1 + wt)
    lg = league_sf(r["date"])
    tr = team_rows(r["opp"], r["date"])[:170]
    ww = xx = 0.0
    for i, (d, g, sa) in enumerate(tr):
        wi = 0.5 ** (i / 25.0); ww += wi; xx += wi * sa
    opp = (10 * lg + xx) / (10 + ww) / lg
    mu = rate * etoi * 0.972 * opp * (1.017 if r["home"] else 0.983)
    k = math.floor(r["line"]) + 1
    rr = 15.7; p = rr / (rr + mu); term = p ** rr; cdf = 0
    for i in range(k):
        cdf += term; term *= (i + rr) / (i + 1) * (1 - p)
    praw = 1 - cdf
    a, b = {0.5: (-0.103, 1.080), 1.5: (0.013, 1.054), 2.5: (0.066, 1.051), 3.5: (0.046, 1.014), 4.5: (0.040, 0.998)}[r["line"]]
    lg_ = math.log(praw / (1 - praw))
    pc = 1 / (1 + math.exp(-(a + b * lg_)))
    print("%s %s %-22s line %.1f mu hand %.4f engine %.4f | p hand %.5f engine %.5f | %s" % (
        r["date"], r["gid"], r["name"], r["line"], mu, r["mu"], pc, r["p_over"], "OK" if abs(pc - r["p_over"]) < 1e-4 else "MISMATCH"))
