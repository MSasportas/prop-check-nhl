import json, os, sys
from collections import Counter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib import *
L = load_lines("shots45")
out = []
out.append("pairs %d, ok %d, why %s" % (len(L), sum(r["ok"] for r in L), Counter(r["why"] for r in L if not r["ok"])))
pg = Counter((r["gid"], r["pid"]) for r in L)
out.append("lines per player-game: %s" % Counter(pg.values()))
out.append("line distribution: %s" % Counter(r["line"] for r in L))
out.append("result: %s" % Counter(r["result"] for r in L))
out.append("shots sum check failed (team sog != skater sog): %d of %d graded" % (sum(1 for r in L if r["result"] == "OK" and not r.get("shots_sum_ok")), sum(1 for r in L if r["result"] == "OK")))
holds = [be(r["over"]) + be(r["under"]) - 1 for r in L if r["over"] is not None and r["under"] is not None]
holds.sort()
out.append("hold pct: min %.3f p1 %.3f p50 %.3f p99 %.3f max %.3f" % (holds[0], holds[len(holds)//100], holds[len(holds)//2], holds[-len(holds)//100], holds[-1]))
pr = [r[s] for r in L for s in ("over", "under") if r[s] is not None]
out.append("price range %d..%d; outside -1000..+1000: %d" % (min(pr), max(pr), sum(1 for p in pr if abs(p) > 1000)))
ages = []
from datetime import datetime
for f in os.listdir(os.path.join(H, "raw", "odds", "shots45")):
    js = json.load(open(os.path.join(H, "raw", "odds", "shots45", f)))
    d = js.get("data") or {}
    for b in d.get("bookmakers", []) or []:
        for m in b["markets"]:
            ts = datetime.fromisoformat(js["timestamp"].replace("Z", "+00:00"))
            lu = datetime.fromisoformat(m["last_update"].replace("Z", "+00:00"))
            ages.append((ts - lu).total_seconds() / 60)
ages.sort()
out.append("market last_update age at snapshot (min): p50 %.1f p90 %.1f p99 %.1f max %.1f; >=60: %d of %d" % (ages[len(ages)//2], ages[int(.9*len(ages))], ages[int(.99*len(ages))], ages[-1], sum(1 for a in ages if a >= 60), len(ages)))
G = json.load(open(os.path.join(H, "raw", "nhl", "games.json")))
tgt = []
for g in G:
    p = os.path.join(H, "raw", "odds", "shots45", "%s.json" % g["id"])
    if os.path.exists(p):
        js = json.load(open(p))
        if js.get("timestamp"):
            st = datetime.fromisoformat(g["start"].replace("Z", "+00:00")); ts = datetime.fromisoformat(js["timestamp"].replace("Z", "+00:00"))
            tgt.append((st - ts).total_seconds() / 60)
tgt.sort()
out.append("snapshot minutes before puck: min %.1f p50 %.1f max %.1f (n %d)" % (tgt[0], tgt[len(tgt)//2], tgt[-1], len(tgt)))
print("\n".join(out))
open(os.path.join(WORK, "sanity.txt"), "w").write("\n".join(out) + "\n")
