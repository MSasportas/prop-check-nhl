"""Run the PRODUCTION engine (repo code, read-only) over every 2025-26 historical Hard Rock snapshot.

python3 -I build.py shots45|shots13|saves45
Writes work/<folder>_lines.jsonl (one row per two-way line, with the model, eligibility, result) and
work/<folder>_picks.json (engine picks per hypothesis H1 capped/uncapped, H2, H3) for shots45.
"""
import bisect
import glob
import gzip
import json
import os
import sys
from datetime import datetime, timezone

H = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.environ["PC_DATA_DIR"] = os.path.join(H, "work", "pcdata")      # nothing ever touches the repo's data/
os.makedirs(os.environ["PC_DATA_DIR"], exist_ok=True)
sys.path.insert(0, "/home/claude/prop-check-nhl/scripts")
import common   # noqa: E402
import engine   # noqa: E402
import grade    # noqa: E402
import model    # noqa: E402
import names    # noqa: E402
import odds     # noqa: E402
import stats    # noqa: E402

RAW = os.path.join(H, "raw")
WORK = os.path.join(H, "work")
DS2 = os.path.join(os.path.dirname(H), "ds2", "dl", "rest")
SEASON = 20252026
GAMES = json.load(open(os.path.join(RAW, "nhl", "games.json")))
DATES, TEAM_PIDS = {}, {}


def load_store():
    rows = []
    for f in sorted(glob.glob(os.path.join(DS2, "skater_summary_20242025_*.json"))):
        rows += json.load(open(f))
    st = stats.Store()
    st.add(stats.compact(20242025, rows, []))
    seed = json.load(gzip.open("/home/claude/prop-check-nhl/data/state/stats_seed_20252026.json.gz"))
    st.add(seed)
    st.finish()
    nm = {}
    for r in rows:
        nm[r["playerId"]] = (r["skaterFullName"], r["lastName"])
    for f in sorted(glob.glob(os.path.join(DS2, "skater_timeonice_20252026_*.json"))):
        for r in json.load(open(f)):
            nm[r["playerId"]] = (r["skaterFullName"], r["lastName"])
    for f in sorted(glob.glob(os.path.join(RAW, "nhl", "rest", "goalie_summary_*.json"))):
        for r in json.load(open(f)):
            nm.setdefault(r["playerId"], (r["goalieFullName"], r["lastName"]))
    return st, nm


def first_last(pid, st, nm):
    if pid in nm:
        full, last = nm[pid]
        first = full[: len(full) - len(last)].strip() if full.endswith(last) else full.split(" ")[0]
        return first, last
    full = (st.players.get(pid) or {}).get("name", "")
    parts = full.split(" ", 1)
    return (parts[0], parts[1] if len(parts) > 1 else "")


def roster(st, nm, g, box):
    """Players whose latest row before the game date is with each team, plus that game's boxscore players."""
    people = {}
    cand = set()
    for t in (g["away"], g["home"]):
        cand |= TEAM_PIDS.get(t, set())
    for pid in cand:
        rows = st.skaters[pid]
        ds = DATES[pid]
        i = bisect.bisect_left(ds, g["date"])
        if i == 0:
            continue
        last = rows[i - 1]
        if last["team"] in (g["away"], g["home"]) and last["season"] >= SEASON - 10001:
            f, l = first_last(pid, st, nm)
            people[pid] = {"id": pid, "first": f, "last": l, "team": last["team"],
                           "pos": (st.players.get(pid) or {}).get("pos")}
    if box:
        for side in ("awayTeam", "homeTeam"):
            ab = box[side]["abbrev"]
            grp = box["playerByGameStats"][side]
            for k in ("forwards", "defense", "goalies"):
                for p in grp.get(k, []):
                    pid = p["playerId"]
                    f, l = first_last(pid, st, nm)
                    if not l:
                        nmd = (p.get("name") or {}).get("default", "")
                        l = nmd.split(" ", 1)[-1]
                    people[pid] = {"id": pid, "first": f, "last": l, "team": ab,
                                   "pos": "G" if k == "goalies" else ("D" if k == "defense" else "F")}
    return list(people.values())


def pdt(s):
    return datetime.fromisoformat(s.replace("Z", "+00:00"))


def main():
    folder = sys.argv[1]
    market_key = "player_total_saves" if folder.startswith("saves") else "player_shots_on_goal"
    market = "saves" if folder.startswith("saves") else "shots"
    cfg = common.load_config()
    st, nm = load_store()
    for pid, rows in st.skaters.items():
        DATES[pid] = [r["date"] for r in rows]
        for r in rows:
            TEAM_PIDS.setdefault(r["team"], set()).add(pid)
    cfgs = {"v2": cfg}
    h2 = json.loads(json.dumps(cfg))
    h2["values"].update(edge_cap=None, lines_allowed={"shots": [1.5, 2.5, 3.5]}, max_per_player=99, max_per_game=99,
                        max_picks_night=None)
    cfgs["A"] = h2
    cfgs["v1"] = common.rules_for(cfg, "2026-10-18")
    by_date = {}
    for g in GAMES:
        by_date.setdefault(g["date"], []).append(g)
    os.makedirs(WORK, exist_ok=True)
    out = open(os.path.join(WORK, "%s_lines.jsonl" % folder), "w")
    picks = {"H1_capped": [], "H1_uncapped": [], "H2": [], "H3_capped": [], "H3_uncapped": []}
    stat = {"games": 0, "with_book": 0, "with_market": 0, "snap_bad": 0, "names_total": 0, "names_unmatched": 0,
            "unmatched": {}, "pairs": 0}
    for slate in sorted(by_date):
        fetches, games, boxes = [], [], {}
        for g in by_date[slate]:
            stat["games"] += 1
            cf = os.path.join(RAW, "odds", folder, "%s.json" % g["id"])
            if not os.path.exists(cf):
                continue
            js = json.load(open(cf))
            data = js.get("data") or {}
            if not data:
                continue
            ts = pdt(js["timestamp"])
            start = pdt(g["start"])
            if folder.endswith("45"):
                target = start.timestamp() - 45 * 60
            else:
                target = datetime.fromisoformat(g["date"] + "T13:00:00").replace(tzinfo=common.ET).timestamp()
            if ts >= start or ts.timestamp() < target - 3 * 3600:
                stat["snap_bad"] += 1
                continue
            bp = os.path.join(RAW, "nhl", "box", "%s.json" % g["id"])
            box = json.load(open(bp)) if os.path.exists(bp) else None
            boxes[g["id"]] = box
            if any(b.get("key") == "hardrockbet" for b in data.get("bookmakers", []) or []):
                stat["with_book"] += 1
            people = roster(st, nm, g, box)
            matcher = names.Matcher(people)
            gg = {"id": g["id"], "away": g["away"], "home": g["home"], "start": g["start"], "date": g["date"]}
            # the production normalizer, with the saves market mapped like the live config
            f = odds.normalize(data, gg, matcher, [market_key], "C", ts, 10, cfg)
            if market in f["markets"]:
                stat["with_market"] += 1
            names_here = {o["name"] for mk in f["markets"].values() for o in mk["outcomes"]}
            stat["names_total"] += len(names_here)
            stat["names_unmatched"] += len(f["unmatched"])
            for u in f["unmatched"]:
                stat["unmatched"][u] = stat["unmatched"].get(u, 0) + 1
            fetches.append(f)
            games.append(gg)
        if not games:
            continue
        odds_doc = {"fetches": fetches}
        view = odds.build_view(odds_doc, cfg)
        now = min(pdt(f["at"]) for f in fetches)
        res = {}
        for gid, box in boxes.items():
            res[gid] = grade.read_box(box) if box else None
        # every line, for H4/H5 and later work
        inp = engine.Inputs(cfg, now, slate, SEASON, games, st, {}, view, {}, {}, [])
        gmap = {g["id"]: g for g in games}
        for gid, gv in view.items():
            mv = gv.get(market)
            if not mv or mv.get("gone"):
                continue
            g = gmap[gid]
            parsed = res.get(gid)
            for (pid, line), pair in mv["pairs"].items():
                stat["pairs"] += 1
                team = pair["team"]
                home = team == g["home"]
                opp = g["away"] if home else g["home"]
                row = {"date": slate, "gid": gid, "pid": pid, "name": pair["name"], "team": team, "opp": opp,
                       "home": home, "line": line, "over": pair["over"], "under": pair["under"], "ok": pair["ok"],
                       "why": pair["why"], "at": common.iso(mv["at"]), "start": g["start"]}
                if market == "shots":
                    pv = inp.player(pid, team)
                    m = inp.model(pid, team, opp, home, "shots", line)
                    row.update(n=pv["n"], n_season=pv["n_season"], n_team=pv["n_team"], sitting=pv["sitting"],
                               missed_last=pv["missed_last"], toi_drop=pv["toi_drop"], thin=pv["thin"], pos=pv["pos"],
                               p_over=None if m is None else m["p_over"], mu=None if m is None else m["mu"],
                               etoi=None if m is None else m["etoi"], opp_f=None if m is None else m["opp_f"])
                else:
                    row["pos"] = "G"
                actual, result = None, "NOBOX"
                if parsed:
                    players, teams_ = parsed
                    p = players.get(pid)
                    if p is None or p.get("toi") in (None, "00:00", "0:00"):
                        result = "VOID"
                    else:
                        actual = p.get(grade.FIELD[market])
                        result = "OK" if actual is not None else "NOSTAT"
                        if market == "shots":
                            t = teams_.get(p["team"])
                            row["shots_sum_ok"] = bool(t and t["sog"] == t["skater_sog"])
                        else:
                            row["starter"] = p.get("starter")
                            row["g_toi"] = p.get("toi")
                            row["g_sa"] = p.get("shotsAgainst")
                row["actual"], row["result"] = actual, result
                out.write(json.dumps(row) + "\n")
        if market != "shots":
            continue
        for tag, c in cfgs.items():
            inp = engine.Inputs(c, now, slate, SEASON, games, st, {}, view, {}, {}, [])
            cands, _ = engine.candidates(inp)
            unc = [{"date": slate, "gid": x["game_id"], "pid": x["pid"], "name": x["name"], "line": x["line"],
                    "side": x["side"], "price": x["price"], "p": x["e"]["p"], "b": x["e"]["b"], "model": x["e"]["model"],
                    "fair": x["e"]["fair"], "edge": x["e"]["margin"], "gap": x["e"]["gap"]} for x in cands]
            if tag == "v2":
                picks["H1_uncapped"] += unc
            elif tag == "A":
                picks["H2"] += unc
            else:
                picks["H3_uncapped"] += unc
            if tag in ("v2", "v1"):
                new, _st = engine.evaluate(inp)
                shown = [e["pick"] for e in new if e["t"] == "shown" and e["kind"] == "single"]
                key = "H1_capped" if tag == "v2" else "H3_capped"
                for s in shown:
                    picks[key].append({"date": slate, "gid": s["game_id"], "pid": s["player_id"], "name": s["player"],
                                       "line": s["line"], "side": s["side"], "price": s["price"], "p": s["p"],
                                       "b": s["breakeven"], "model": s["model"], "fair": s["fair"], "rank": s["rank"]})
        print(slate, len(games), {k: len(v) for k, v in picks.items()}, flush=True)
    out.close()
    stat["unmatched_top"] = sorted(stat.pop("unmatched").items(), key=lambda kv: -kv[1])[:40]
    json.dump(stat, open(os.path.join(WORK, "%s_stat.json" % folder), "w"), indent=1)
    if market == "shots":
        json.dump(picks, open(os.path.join(WORK, "%s_picks.json" % folder), "w"))
    print(json.dumps({k: v for k, v in stat.items() if k != "unmatched_top"}))


if __name__ == "__main__":
    main()
