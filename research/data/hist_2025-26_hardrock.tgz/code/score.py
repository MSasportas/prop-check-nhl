"""Score the pre-registered hypotheses H1-H5 (TEAM.md item 19). No tuning here. Writes work/h_results.md + h_results.json"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib import *  # noqa

L = load_lines("shots45")
IX = index(L)
P = json.load(open(os.path.join(WORK, "shots45_picks.json")))
out, js = [], {}


def bets_of(picks):
    bs, void = [], 0
    for p in picks:
        b = grade_bet(IX.get((p["gid"], p["pid"], p["line"])), p["side"], p["price"])
        if b is None:
            void += 1
            continue
        b["edge"] = p["p"] - p["b"]
        b["pid"] = p["pid"]
        bs.append(b)
    return bs, void


out.append("# Pre-registered hypotheses H1-H5 (2025-26 Hard Rock, -45 min snapshot, current code/config)\n")
for key, title in (("H1_uncapped", "H1 v2.0 uncapped (every qualifying side)"),
                   ("H1_capped", "H1 v2.0 capped (engine.evaluate: best line per player, 2/game, 8/night by edge)"),
                   ("H2", "H2 rule A (no edge cap, lines 1.5/2.5/3.5, no caps)"),
                   ("H3_capped", "H3 v1.0 (engine.evaluate, v1 caps)"),
                   ("H3_uncapped", "H3 v1.0 uncapped")):
    bs, void = bets_of(P[key])
    s = summ(bs)
    js[key] = s
    out.append(table(bs, title) + "\nvoid/no result: %d\n" % void)
    if key.startswith("H1"):
        # positive months
        mo = breakdown(bs, lambda b: b["month"])
        js[key + "_months_pos"] = sum(1 for v in mo.values() if v["units"] > 0)
        js[key + "_months"] = len(mo)
        eb = breakdown(bs, lambda b: "%.2f-%.2f" % (int(b["edge"] / 0.01) * 0.01, int(b["edge"] / 0.01) * 0.01 + 0.01))
        out.append("| edge band | n | hit | BE | units | ROI |\n|---|---|---|---|---|---|")
        for k, v in eb.items():
            out.append("| %s | %d | %.1f%% | %.1f%% | %+.1f | %+.1f%% |" % (k, v["n"], 100 * v["hit"], 100 * v["be"], v["units"], 100 * v["roi"]))
        out.append("")

# H4 blind unders 1.5 + 2.5
h4 = []
for r in L:
    if r["ok"] and r["line"] in (1.5, 2.5) and in_gate(r["under"]):
        b = grade_bet(r, "under", r["under"])
        if b:
            h4.append(b)
js["H4"] = summ(h4)
out.append(table(h4, "H4 blind unders 1.5 + 2.5, -200..+120, ok pairs"))
h4o = []
for r in L:
    if r["ok"] and r["line"] in (1.5, 2.5) and in_gate(r["over"]):
        b = grade_bet(r, "over", r["over"])
        if b:
            h4o.append(b)
js["H4_overs_ref"] = summ(h4o)
out.append("Reference (not a hypothesis): blind overs 1.5 + 2.5 in gate: " + fmt(js["H4_overs_ref"]) + "\n")

# H5 log loss / Brier
pop = [r for r in L if r["ok"] and r["result"] == "OK" and r.get("p_over") is not None and r["n"] >= 10
       and not r["sitting"] and r["actual"] != r["line"]]
out.append("### H5 log loss / Brier, model vs book (every ok two-way line, model eligible: n>=10, not sitting)\n")
out.append("n lines = %d\n" % len(pop))


def scores(rows):
    res = {"n": len(rows)}
    for nm, f in (("model", lambda r: r["p_over"]),
                  ("blend70_oh", lambda r: 0.7 * r["p_over"] + 0.3 * (1 - be(r["under"]))),
                  ("book_overhold", lambda r: 1 - be(r["under"])),
                  ("book_prop", lambda r: be(r["over"]) / (be(r["over"]) + be(r["under"])))):
        lls = [ll(f(r), 1 if r["actual"] > r["line"] else 0) for r in rows]
        br = [(f(r) - (1 if r["actual"] > r["line"] else 0)) ** 2 for r in rows]
        res[nm] = (sum(lls) / len(lls), sum(br) / len(br))
    return res


def boot_diff(rows, a, b, B=1000, seed=5):
    import random
    by = {}
    for r in rows:
        y = 1 if r["actual"] > r["line"] else 0
        by.setdefault(r["gid"], []).append(ll(a(r), y) - ll(b(r), y))
    g = [(sum(v), len(v)) for v in by.values()]
    rnd = random.Random(seed)
    rs = []
    for _ in range(B):
        s = c = 0
        for _ in range(len(g)):
            x = g[rnd.randrange(len(g))]
            s += x[0]; c += x[1]
        rs.append(s / c)
    rs.sort()
    return sum(x[0] for x in g) / sum(x[1] for x in g), rs[int(0.025 * B)], rs[int(0.975 * B)]


fm = lambda r: r["p_over"]
foh = lambda r: 1 - be(r["under"])
fpr = lambda r: be(r["over"]) / (be(r["over"]) + be(r["under"]))
fbl = lambda r: 0.7 * r["p_over"] + 0.3 * (1 - be(r["under"]))
out.append("| month | n | LL model | LL blend 0.7 | LL book over-hold | LL book prop | Brier model | Brier over-hold | Brier prop |")
out.append("|---|---|---|---|---|---|---|---|---|")
mon = sorted({r["date"][:7] for r in pop})
for m in mon + ["ALL"]:
    rows = pop if m == "ALL" else [r for r in pop if r["date"][:7] == m]
    s = scores(rows)
    out.append("| %s | %d | %.4f | %.4f | %.4f | %.4f | %.4f | %.4f | %.4f |" % (
        m, s["n"], s["model"][0], s["blend70_oh"][0], s["book_overhold"][0], s["book_prop"][0], s["model"][1], s["book_overhold"][1], s["book_prop"][1]))
    if m == "ALL":
        js["H5"] = s
d1 = boot_diff(pop, fm, foh)
d2 = boot_diff(pop, fm, fpr)
d3 = boot_diff(pop, fbl, foh)
js["H5_diff"] = {"model-overhold": d1, "model-prop": d2, "blend-overhold": d3}
out.append("\nLL difference (negative = first is better), game-clustered 95%%: model - over-hold %+.4f [%+.4f,%+.4f]; "
           "model - prop %+.4f [%+.4f,%+.4f]; blend0.7 - over-hold %+.4f [%+.4f,%+.4f]\n" % (d1 + d2 + d3))
for ln in (1.5, 2.5, 3.5):
    rows = [r for r in pop if r["line"] == ln]
    if rows:
        s = scores(rows)
        out.append("line %.1f n=%d LL model %.4f over-hold %.4f prop %.4f" % (ln, s["n"], s["model"][0], s["book_overhold"][0], s["book_prop"][0]))
out.append("")

# over-hold structure: share of hold on the over, by month and line
out.append("### Hard Rock hold split (all ok two-way lines with a result)\n")
out.append("k = share of the hold that sits on the over, solved from mean(over break-even) - mean(over hit) = k * mean(hold). k=1: all on the over, 0.5: even.\n")
out.append("| slice | n | hold | over BE | over hit | k | blind over ROI | blind under ROI |")
out.append("|---|---|---|---|---|---|---|---|")
allok = [r for r in L if r["ok"] and r["result"] == "OK" and r["actual"] != r["line"]]


def ksplit(rows):
    n = len(rows)
    hold = sum(be(r["over"]) + be(r["under"]) - 1 for r in rows) / n
    obe = sum(be(r["over"]) for r in rows) / n
    hit = sum(1 for r in rows if r["actual"] > r["line"]) / n
    ro = sum((dec(r["over"]) - 1) if r["actual"] > r["line"] else -1 for r in rows) / n
    ru = sum((dec(r["under"]) - 1) if r["actual"] < r["line"] else -1 for r in rows) / n
    return n, hold, obe, hit, (obe - hit) / hold, ro, ru


ks = {}
for nm, rows in [("ALL", allok)] + [(m, [r for r in allok if r["date"][:7] == m]) for m in mon] + \
        [("line %.1f" % ln, [r for r in allok if r["line"] == ln]) for ln in (0.5, 1.5, 2.5, 3.5, 4.5)]:
    if len(rows) < 30:
        continue
    k = ksplit(rows)
    ks[nm] = k
    out.append("| %s | %d | %.1f%% | %.1f%% | %.1f%% | %.2f | %+.1f%% | %+.1f%% |" % (nm, k[0], 100 * k[1], 100 * k[2], 100 * k[3], k[4], 100 * k[5], 100 * k[6]))
js["holdsplit"] = ks
open(os.path.join(WORK, "h_results.md"), "w").write("\n".join(out) + "\n")
json.dump(js, open(os.path.join(WORK, "h_results.json"), "w"), indent=1)
print("\n".join(out))
