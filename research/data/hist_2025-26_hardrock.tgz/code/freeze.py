"""Freeze the best walk-forward family's rule, refit on ALL pre-lockbox months. Writes work/frozen.json. Does not score the lockbox."""
import json, os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import walkforward as W
NAMES = ["all games", "team NOT on a back-to-back", "team on a back-to-back", "opponent NOT on a back-to-back",
         "opponent on a back-to-back", "team rested 2+ days", "opponent rested 2+ days"]
train = W.DEV
for i, g in enumerate(W.F_rest.grid):
    bs = W.bets_for(train, g)
    print(i, NAMES[i], len(bs), round(W.roi(bs) * 100, 2))
prm, _ = W.F_rest(train)
i = next(j for j, g in enumerate(W.F_rest.grid) if g is prm)
fz = {"frozen_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "family": "rest / back-to-back (best walk-forward OOS ROI, -0.2%)",
      "rule": "v2.0 exactly (over-hold, 0.7 blend, edge 0..0.05, lines 1.5/2.5, uncapped) restricted to: " + NAMES[i], "grid_index": i,
      "fit_on": "2025-10-07..2026-02-28", "lockbox": "2026-03-01..2026-04-16, scored once after this file is written"}
json.dump(fz, open(os.path.join(W.WORK, "frozen.json"), "w"), indent=1)
print(json.dumps(fz, indent=1))
