"""Open (1 PM ET) -> close (-45 min) movement on the 1 PM sample; CLV of v2 picks made at 1 PM."""
import json, math, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib import *
O = load_lines("shots13"); C = index(load_lines("shots45"))
P = json.load(open(os.path.join(WORK, "shots13_picks.json")))
out = ["# CLV: 1 PM ET read -> 45-min read (%d games in the 1 PM sample)\n" % len({r['gid'] for r in O})]
def clus(vals):
    by = {}
    for g, v in vals: by.setdefault(g, []).append(v)
    n = len(vals); m = sum(v for _, v in vals) / n
    # cluster-robust SE of the mean
    s2 = sum((sum(v) - len(v) * m) ** 2 for v in by.values()) / (n * n)
    se = math.sqrt(s2 * len(by) / max(1, len(by) - 1))
    return n, m, se, m / se if se else 0
same = moved = gone = 0
dl = []; dm = []
for r in O:
    c = C.get((r["gid"], r["pid"], r["line"]))
    if c is None:
        # line moved or gone
        if any(k[0] == r["gid"] and k[1] == r["pid"] for k in ()): pass
        gone += 1; continue
    same += 1
    if r["ok"] and c["ok"]:
        d = fair_over(c, None) - fair_over(r, None)
        dl.append((r["gid"], d))
        if r.get("p_over") is not None:
            dm.append((r["p_over"] - fair_over(r, None), d))
out.append("1 PM lines %d: same line at close %d, line changed/gone %d" % (len(O), same, gone))
n, m, se, t = clus(dl)
out.append("mean move of proportional fair over: %+.4f (se %.4f, t %.1f, n %d)" % (m, se, t, n))
if dm:
    xs = [a for a, _ in dm]; ys = [b for _, b in dm]; mx = sum(xs) / len(xs); my = sum(ys) / len(ys)
    b = sum((x - mx) * (y - my) for x, y in dm) / sum((x - mx) ** 2 for x in xs)
    out.append("close move vs open gap (model - book prop): slope %.3f (share of the gap the price moves toward the model)" % b)
for key in ("H1_uncapped", "H1_capped"):
    vals, valsf, bets = [], [], []
    miss = 0
    for p in P[key]:
        c = C.get((p["gid"], p["pid"], p["line"]))
        o = next((r for r in O if r["gid"] == p["gid"] and r["pid"] == p["pid"] and r["line"] == p["line"]), None)
        if c is None or not c["ok"]:
            miss += 1; continue
        vals.append((p["gid"], be(c[p["side"]]) - be(p["price"])))
        fo_c, fo_o = fair_over(c, None), fair_over(o, None)
        valsf.append((p["gid"], (fo_c - fo_o) * (1 if p["side"] == "over" else -1)))
        b = grade_bet(c, p["side"], p["price"])
        if b: bets.append(b)
    n, m, se, t = clus(vals); n2, m2, se2, t2 = clus(valsf)
    out.append("\n%s picks at 1 PM: %d (no close line %d). CLV (close break-even - pick break-even, our side): %+.2f pts (t %.1f). De-vigged fair move toward our side: %+.2f pts (t %.1f). Graded at 1 PM price: %s" % (
        key, len(P[key]), miss, 100 * m, t, 100 * m2, t2, fmt(summ(bets))))
open(os.path.join(WORK, "clv.md"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
