"""Stage the historical pulls. python3 -I pull.py events|shots45|saves45|shots13 [limit]"""
import json
import os
import random
import sys
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import oddsapi  # noqa: E402

sys.path.insert(0, "/home/claude/prop-check-nhl/scripts")
import teams  # noqa: E402

H = oddsapi.H
RAW = os.path.join(H, "raw")
ET = ZoneInfo("America/New_York")
GAMES = json.load(open(os.path.join(RAW, "nhl", "games.json")))


def iso(dt):
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def pdt(s):
    return datetime.fromisoformat(s.replace("Z", "+00:00"))


def events():
    days = sorted({g["date"] for g in GAMES})
    for d in days:
        noon = datetime.fromisoformat(d + "T12:00:00").replace(tzinfo=ET)
        cf = os.path.join(RAW, "odds", "events", d + ".json")
        oddsapi.get("/events", {"date": iso(noon)}, cf, 1)
    print("events done", len(days))


def match():
    """game id -> event id, by teams + start within 6 h (odds.match_events rule)."""
    out, unknown = {}, set()
    for g in GAMES:
        cf = os.path.join(RAW, "odds", "events", g["date"] + ".json")
        js = json.load(open(cf)) if os.path.exists(cf) else {}
        for e in js.get("data", []) or []:
            a, h = teams.abbrev_for(e.get("away_team")), teams.abbrev_for(e.get("home_team"))
            if not a or not h:
                unknown.add((e.get("away_team"), e.get("home_team")))
                continue
            if a == g["away"] and h == g["home"] and abs((pdt(e["commence_time"]) - pdt(g["start"])).total_seconds()) <= 6 * 3600:
                out[str(g["id"])] = {"event": e["id"], "commence": e["commence_time"]}
    json.dump(out, open(os.path.join(RAW, "odds", "match.json"), "w"), indent=0)
    print("matched", len(out), "of", len(GAMES), "unknown team names", sorted(unknown)[:5])
    return out


def odds_at(gid, ev, when, market, folder):
    cf = os.path.join(RAW, "odds", folder, "%s.json" % gid)
    return oddsapi.get("/events/%s/odds" % ev, {"date": iso(when), "regions": "us2", "bookmakers": "hardrockbet",
                                                 "markets": market, "oddsFormat": "american"}, cf, 10)


def sample(seed, n, exclude=()):
    by_month = {}
    for g in GAMES:
        by_month.setdefault(g["date"][:7], []).append(g)
    rnd = random.Random(seed)
    tot = len(GAMES)
    out = []
    for m, gs in sorted(by_month.items()):
        k = round(n * len(gs) / tot)
        gs = [g for g in gs if g["id"] not in exclude]
        out += rnd.sample(gs, min(k, len(gs)))
    return out


def main():
    what = sys.argv[1]
    lim = int(sys.argv[2]) if len(sys.argv) > 2 else 10 ** 9
    if what == "events":
        events()
        match()
        return
    m = json.load(open(os.path.join(RAW, "odds", "match.json")))
    if what == "shots45":
        todo = GAMES
        market, folder, off = "player_shots_on_goal", "shots45", None
    elif what == "saves45":
        todo = sample(19, 250)
        market, folder, off = "player_total_saves", "saves45", None
    elif what == "shots13":
        todo = sample(23, 150)
        market, folder, off = "player_shots_on_goal", "shots13", "13"
    n = 0
    try:
        for g in todo:
            if n >= lim:
                break
            x = m.get(str(g["id"]))
            if not x:
                continue
            start = pdt(g["start"])
            if off == "13":
                when = datetime.fromisoformat(g["date"] + "T13:00:00").replace(tzinfo=ET)
                if when >= start - timedelta(minutes=90):
                    continue                     # an afternoon game: no separate open read
            else:
                when = start - timedelta(minutes=45)
            cf = os.path.join(RAW, "odds", folder, "%s.json" % g["id"])
            had = os.path.exists(cf)
            odds_at(g["id"], x["event"], when, market, folder)
            n += 0 if had else 1
    except oddsapi.CapReached as e:
        print("STOP:", e)
    print(what, "new calls", n, "credits used", oddsapi.used_so_far())


if __name__ == "__main__":
    main()
