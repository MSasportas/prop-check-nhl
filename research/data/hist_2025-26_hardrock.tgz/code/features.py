"""Context features for exploratory work, each from games strictly before the row's date."""
import bisect, glob, gzip, json, os, sys
from datetime import date
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib import *
folder = sys.argv[1]
G = json.load(open(os.path.join(H, "raw", "nhl", "games.json")))
td = {}
for g in G:
    for t in (g["away"], g["home"]):
        td.setdefault(t, []).append(g["date"])
for t in td: td[t] = sorted(set(td[t]))
def rest(t, d):
    ds = td.get(t, []); i = bisect.bisect_left(ds, d)
    if i == 0: return None
    return (date.fromisoformat(d) - date.fromisoformat(ds[i - 1])).days - 1
DS2 = os.path.join(os.path.dirname(H), "ds2", "dl", "rest")
pp = {}
for f in sorted(glob.glob(os.path.join(DS2, "skater_timeonice_20252026_*.json"))):
    for r in json.load(open(f)):
        pp.setdefault(r["playerId"], []).append((r["gameDate"][:10], r["ppTimeOnIce"] or 0, r["timeOnIce"] or 0))
for k in pp: pp[k].sort()
seed = json.load(gzip.open("/home/claude/prop-check-nhl/data/state/stats_seed_20252026.json.gz"))
rows24 = []
for f in sorted(glob.glob(os.path.join(DS2, "skater_summary_20242025_*.json"))):
    rows24 += json.load(open(f))
toi = {}
for r in rows24: toi.setdefault(r["playerId"], []).append((r["gameDate"][:10], r["timeOnIcePerGame"] or 0))
for r in seed["skaters"]: toi.setdefault(r[0], []).append((r[2], r[6]))
for k in toi: toi[k].sort()
L = load_lines(folder)
out = open(os.path.join(WORK, "%s_feat.jsonl" % folder), "w")
for r in L:
    r["team_rest"], r["opp_rest"] = rest(r["team"], r["date"]), rest(r["opp"], r["date"])
    if r.get("pos") != "G":
        xs = pp.get(r["pid"], []); i = bisect.bisect_left(xs, (r["date"],))
        prev = xs[max(0, i - 10):i]
        r["pp_share"] = (sum(x[1] for x in prev) / max(1, sum(x[2] for x in prev))) if len(prev) >= 3 else None
        r["pp_min"] = (sum(x[1] for x in prev) / len(prev) / 60) if len(prev) >= 3 else None
        ts = toi.get(r["pid"], []); i = bisect.bisect_left(ts, (r["date"],))
        l5, l20 = ts[max(0, i - 5):i], ts[max(0, i - 20):i]
        r["toi_trend"] = (sum(x[1] for x in l5) / len(l5) - sum(x[1] for x in l20) / len(l20)) / 60 if len(l20) >= 10 else None
    out.write(json.dumps(r) + "\n")
out.close()
print("ok", len(L))
