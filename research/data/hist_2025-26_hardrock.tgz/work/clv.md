# CLV: 1 PM ET read -> 45-min read (144 games in the 1 PM sample)

1 PM lines 1989: same line at close 1947, line changed/gone 42
mean move of proportional fair over: +0.0000 (se 0.0003, t 0.1, n 1945)
close move vs open gap (model - book prop): slope 0.029 (share of the gap the price moves toward the model)

H1_uncapped picks at 1 PM: 412 (no close line 5). CLV (close break-even - pick break-even, our side): +0.08 pts (t 2.0). De-vigged fair move toward our side: +0.07 pts (t 2.0). Graded at 1 PM price: n=406 hit 56.2% BE 54.2% +13.8u ROI +3.4% 90% [-4.3,+11.1] 95% [-5.7,+12.4]

H1_capped picks at 1 PM: 230 (no close line 2). CLV (close break-even - pick break-even, our side): +0.11 pts (t 2.3). De-vigged fair move toward our side: +0.10 pts (t 2.3). Graded at 1 PM price: n=228 hit 55.7% BE 53.9% +7.7u ROI +3.4% 90% [-7.7,+14.3] 95% [-9.4,+16.5]
