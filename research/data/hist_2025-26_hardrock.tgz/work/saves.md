# Saves sample (Hard Rock, -45 min, 233 games, 406 graded two-way lines)

LL production goalie_prob   0.6931  Brier 0.2500
LL goalie-specific (sv%)    0.7026  Brier 0.2547
LL book over-hold           0.6916  Brier 0.2492
LL book proportional        0.6921  Brier 0.2495

hold 7.0%, over BE 53.7%, over hit 48.0%, k (share of hold on over) 0.81
blind overs n=406 hit 48.0% BE 53.7% -43.2u ROI -10.6% 90% [-17.6,-3.8] 95% [-19.0,-2.3]
blind unders n=406 hit 52.0% BE 53.3% -10.3u ROI -2.5% 90% [-9.5,+4.6] 95% [-11.0,+6.0]

v2-style rule on saves, pre-March only (Oct-Feb, no fit; lockbox untouched):
  production model: n=47 hit 55.3% BE 53.4% +1.5u ROI +3.1% 90% [-17.6,+24.7] 95% [-22.4,+29.1]
  goalie-specific : n=98 hit 42.9% BE 53.5% -19.7u ROI -20.1% 90% [-35.3,-4.2] 95% [-38.4,-1.5]
  walk-forward p_over (16 variants): n=31 hit 51.6% BE 53.6% -1.3u ROI -4.3% 90% [-30.8,+24.9] 95% [-35.5,+29.6]  picks [('2026-01', (1.0, 0, 0.05), 24), ('2026-02', (0.3, 0, 0.05), 7)]
  walk-forward p2_over (16 variants): n=127 hit 46.5% BE 53.8% -17.7u ROI -13.9% 90% [-27.0,+0.1] 95% [-29.4,+3.7]  picks [('2025-11', (1.0, 0, None), 41), ('2025-12', (1.0, 0, 0.05), 32), ('2026-01', (1.0, 0, 0.05), 45), ('2026-02', (1.0, 0, 0.05), 9)]
