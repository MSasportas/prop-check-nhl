# Historical backtest, 2025-26 Hard Rock shots props (TEAM.md item 19, pre-registered)

DS, 2026-10-19. Plan: PLAN.md. Detail: work/h_results.md, work/walkforward.md, work/clv.md, work/saves.md,
work/placebo.txt, work/sanity.txt, work/frozen.json, work/lockbox.txt. Scripts: code/. Raw cache: raw/. Credits: ledger.jsonl.

## Data
- Credits: 16,818 of 20,000 used (cap 18,000), 1,874 calls, all HTTP 200. Key never written anywhere (checked by grep).
- Shots at -45 min (actual snapshot 49 min before the NHL start time, 5-min grid): 1,311 of 1,312 games pulled
  (NSH@PIT Nov 16, 9 AM start, was not on the noon events list), 1,287 had Hard Rock shots, 18,383 two-way lines
  (one line per player per game; 1.5: 10,332, 2.5: 6,841, 3.5: 1,171, 4.5: 36, 0.5: 3). 13 failed feed checks.
  Snapshot freshness fine (market last_update median 0.3 min old, max 4.8).
- Names: 126 of 18,509 feed names unmatched (0.7%): Elias Pettersson x74 (two VAN players, the matcher refuses to
  guess, same as live), Yegor Chinakhov x44 (NHL spells it differently: live has this gap too), A.J. Greer x8.
- Results from NHL boxscores (grade.py read_box/result_for): 132 void, 53 lines where team SOG != skater SOG (graded anyway).
- Saves at -45: 250-game stratified sample, 233 with Hard Rock saves, 406 graded lines. 1 PM shots: 146-game sample, 1,989 lines.
- Leakage: production engine.Inputs/candidates/evaluate imported read-only; store rows date < slate only; independent
  hand recompute of 6 lines matched mu and p to 5 decimals; the replica rule reproduces the engine's H1 set exactly (3,943/3,943).
  model.py params are stated as fit on 2024-25. Nothing in model.py was refit on 2025-26, but 2025-26 outcomes were
  seen when v1.0 was designed (TEAM item 1 "backtest 2025-26"), so H3 is not perfectly clean; v2 values were set on Oct 2026 lines.
- No lineups: every pick is "early"; missed-last-game players excluded (as live without a lineup).

## H1-H5 (exact current code/config, no tuning)
| Hyp | n | hit | BE | units | ROI | 90% CI | 95% CI | months > 0 |
|---|---|---|---|---|---|---|---|---|
| H1 v2.0 uncapped | 3,918 | 52.6% | 54.2% | -106.5 | **-2.7%** | -5.2..-0.2 | -5.7..+0.4 | 1 of 7 |
| H1 v2.0 capped (1/player, 2/game, 8/night) | 1,198 | 50.1% | 53.5% | -72.5 | **-6.1%** | -10.3..-1.9 | -11.3..-1.1 | 2 of 7 |
| H2 rule A | 4,774 | 53.8% | 54.6% | -67.5 | -1.4% | -3.5..+0.8 | -4.0..+1.3 | 2 of 7 |
| H3 v1.0 | 3 | 33% | 56% | -1.1 | n/a | | | |
| H4 blind unders 1.5+2.5 | 13,427 | 51.2% | 54.6% | -849.1 | -6.3% | -7.7..-4.9 | -7.9..-4.6 | 0 of 7 |
| (ref) blind overs 1.5+2.5 | 14,947 | 53.2% | 56.6% | -927.1 | -6.2% | -7.5..-5.0 | | |

H1 FAILS the pre-registered bar (needed ROI >= +3%, 90% low > 0, 4 of 6 months positive). By the fail rule: ROI <= 0.
Capped is worse than uncapped: ranking by edge picks worse bets (edge does not sort winners; 0.02-0.03 band -7.9%).
H1 is 95% unders. H3: v1.0 almost never qualifies early (3 bets all season), as TEAM item 17 predicted.

H5 (17,805 eligible lines): log loss model 0.6832, blend 0.7 0.6825, book over-hold 0.6836, **book proportional 0.6814**.
Model minus proportional book +0.0019 (95% +0.0005..+0.0032): the book is better than the model. The model only "beats"
the over-hold book because over-hold is the wrong de-vig. Model level bias on listed lines: stated over 53.2% vs hit 55.0%
(1.5), 44.5% vs 46.0% (2.5), 41.2% vs 43.8% (3.5): the model leans under by ~1.5-2.5 pts, which is where the "under edges" come from.

## Over-hold finding: not structural
Share of the 7.0% hold on the over (k; 1 = all on over): season **0.52** (even split). By month: Oct 0.45, Nov 0.58,
Dec 0.38, Jan 0.29, Feb 0.33, Mar 0.80, Apr 0.75. By line: 1.5 0.44, 2.5 0.61, 3.5 0.77. Blind overs -6.9%, blind unders -6.6%.
The Oct 2026 week (k~1) looks like the late-season pattern or noise, not a fixed Hard Rock policy. Saves sample k = 0.81 (n 406).

## CLV (1 PM -> 45 min, 144 games)
Hard Rock prices barely move: 81% of lines identical, mean fair move 0.000, only 2.9% of the model-book gap closes.
v2 picks made at 1 PM: CLV +0.08 pts (t 2.0), capped +0.11 (t 2.3). Real but ~1/20th of what the vig costs.

## Placebo
Model shuffled within night x line (500 runs): mean ROI -5.2% (5-95% -7.2..-3.2); real -2.7%; p = 0.02.
The model carries information, just not enough to clear a 7% hold.

## Walk-forward (Nov-Feb test months, 156 variants, 11 families)
Every family was negative OOS: v2 reference -4.6%; best were rest/back-to-back -0.2% (n 1,054) and opponent shot
suppression -0.2% (n 714); line subsets -2.6%, TOI trend -1.4%, PP role -3.3%, edge band -13.2%, price band -7.7%,
fitted blend: train log loss picks w 0.1-0.4 and k 0.25-0.5, i.e. "trust the book", leaving ~no bets; stacked logistic gives
the model a 0.14-0.19 weight vs 0.95 for the book. ~0.6 families would look significant by chance; none even reached ROI > 0.
Saves (production goalie_prob and a goalie save% variant): both worse than the book in log loss; walk-forward -4.3% (n 31)
and -13.9% (n 127). Nothing.

## Frozen candidate and lockbox
Frozen 2026-10-19 14:18 UTC (work/frozen.json): v2.0 restricted to "team on a back-to-back" (fit Oct-Feb: -1.0% in-sample).
Lockbox Mar 1-Apr 16, scored once: n 268, 55.6% vs 55.0% BE, +6.6u, **+2.4%**, 90% -6.8..+11.4. Noise; March-April were
the friendliest months for every under rule (H1 +0.2%/-0.2%, H4 -1.2%/-3.0%), so this is not evidence.

## Verdict
v2.0 is not a profitable edge at Hard Rock posted prices. Full season -2.7% uncapped, -6.1% as the page caps it, 1 of 7
months positive, failing the pre-registered bar. The over-hold premise is false over a season, the model is worse than the
book's own prices, and no walk-forward idea found anything.
